package com.example.nativeexe;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public final class NativeBridge {
    static {
        System.loadLibrary("native-lib");
    }

    private NativeBridge() {}

    // JNI (implemented in jni/native-lib.cpp)
    public static native String version();
    public static native int add(int a, int b);

    /** Runs the packaged executable (libnativeexe.so in nativeLibraryDir) and returns its output. */
    public static String runExecutable(Context ctx, String... args) throws IOException, InterruptedException {
        File exe = new File(ctx.getApplicationInfo().nativeLibraryDir, "libnativeexe.so");
        List<String> cmd = new ArrayList<>();
        cmd.add(exe.getAbsolutePath());
        for (String a : args) cmd.add(a);

        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        StringBuilder out = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line;
            while ((line = r.readLine()) != null) out.append(line).append('\n');
        }
        if (!p.waitFor(5, TimeUnit.SECONDS)) p.destroyForcibly();
        return out.toString();
    }
}
