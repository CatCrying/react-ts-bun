package com.example.nativeexe;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView tv = new TextView(this);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setPadding(32, 32, 32, 32);
        ScrollView sv = new ScrollView(this);
        sv.setFitsSystemWindows(true); // targetSdk 35 is edge-to-edge
        sv.addView(tv);
        setContentView(sv);

        tv.setText("JNI: " + NativeBridge.version()
                + "\nadd(2, 3) = " + NativeBridge.add(2, 3)
                + "\n\nRunning executable...");

        new Thread(() -> {
            String result;
            try {
                result = NativeBridge.runExecutable(this, "add", "40", "2");
            } catch (Exception e) {
                result = "error: " + e;
            }
            final String text = tv.getText() + "\n" + result;
            runOnUiThread(() -> tv.setText(text));
        }).start();
    }
}
