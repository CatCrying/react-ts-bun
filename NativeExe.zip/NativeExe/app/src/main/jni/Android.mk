LOCAL_PATH := $(call my-dir)

# ---------- Shared code (static library) ----------
include $(CLEAR_VARS)
LOCAL_MODULE    := core
LOCAL_SRC_FILES := core.cpp
LOCAL_C_INCLUDES        := $(LOCAL_PATH)
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)
include $(BUILD_STATIC_LIBRARY)

# ---------- JNI library -> libnative-lib.so ----------
include $(CLEAR_VARS)
LOCAL_MODULE           := native-lib
LOCAL_SRC_FILES        := native-lib.cpp
LOCAL_STATIC_LIBRARIES := core
LOCAL_LDLIBS           := -llog
include $(BUILD_SHARED_LIBRARY)

# ---------- Standalone executable -> nativeexe ----------
include $(CLEAR_VARS)
LOCAL_MODULE           := nativeexe
LOCAL_SRC_FILES        := main.cpp
LOCAL_STATIC_LIBRARIES := core
include $(BUILD_EXECUTABLE)
