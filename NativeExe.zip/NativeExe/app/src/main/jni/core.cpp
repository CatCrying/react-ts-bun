#include "core.h"

namespace core {

static const char* abi_name() {
#if defined(__aarch64__)
    return "arm64-v8a";
#elif defined(__arm__)
    return "armeabi-v7a";
#elif defined(__x86_64__)
    return "x86_64";
#elif defined(__i386__)
    return "x86";
#else
    return "unknown";
#endif
}

std::string version() {
    return std::string("core 1.0 [") + abi_name() + "]";
}

int add(int a, int b) {
    return a + b;
}

}  // namespace core
