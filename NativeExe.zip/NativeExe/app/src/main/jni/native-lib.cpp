#include <jni.h>
#include <android/log.h>

#include "core.h"

#define TAG "NativeExe"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM*, void*) {
    LOGI("libnative-lib loaded: %s", core::version().c_str());
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_nativeexe_NativeBridge_version(JNIEnv* env, jclass) {
    return env->NewStringUTF(core::version().c_str());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_nativeexe_NativeBridge_add(JNIEnv*, jclass, jint a, jint b) {
    return core::add(a, b);
}
