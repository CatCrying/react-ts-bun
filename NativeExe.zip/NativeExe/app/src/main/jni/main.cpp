#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

#include "core.h"

int main(int argc, char** argv) {
    std::printf("nativeexe: %s\n", core::version().c_str());
    std::printf("pid=%d uid=%d\n", static_cast<int>(getpid()), static_cast<int>(getuid()));

    // usage: nativeexe add <a> <b>
    if (argc >= 4 && std::strcmp(argv[1], "add") == 0) {
        std::printf("%d\n", core::add(std::atoi(argv[2]), std::atoi(argv[3])));
    }
    return 0;
}
