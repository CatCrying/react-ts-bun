# Gradle overrides APP_ABI on the command line; this default is for manual `ndk-build` runs.
APP_ABI      := arm64-v8a
APP_PLATFORM := android-24
APP_STL      := c++_static
APP_CFLAGS   := -O2 -Wall -Wextra
APP_CPPFLAGS := -std=c++20

# NDK r27+: 16 KB page-size compatible ELF alignment (required for new Play targets)
APP_SUPPORT_FLEXIBLE_PAGE_SIZES := true
