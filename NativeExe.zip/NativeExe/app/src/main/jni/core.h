#pragma once
#include <string>

namespace core {

std::string version();
int add(int a, int b);

}  // namespace core
