import javax.inject.Inject
import org.gradle.process.ExecOperations

plugins {
    id("com.android.application")
}

val nativeAbis = listOf("arm64-v8a", "armeabi-v7a")
val ndkVer = "27.2.12479018" // NDK r27c (LTS). Check: sdkmanager --list | grep ndk

/**
 * Runs ndk-build for BOTH modules in jni/Android.mk:
 *   - libnative-lib.so  (JNI shared library)
 *   - nativeexe         (standalone executable)
 *
 * Results:
 *   build/ndk/libs/<abi>/libnative-lib.so
 *   build/ndk/libs/<abi>/libnativeexe.so   <- executable renamed so AGP packages it
 *   build/ndk/exe/<abi>/nativeexe          <- original name, for `adb push`
 */
abstract class NdkBuildTask @Inject constructor(
    private val execOps: ExecOperations
) : DefaultTask() {

    @get:Input abstract val ndkDir: Property<String>
    @get:Input abstract val abis: ListProperty<String>
    @get:Input abstract val debug: Property<Boolean>

    @get:InputDirectory
    @get:PathSensitive(PathSensitivity.RELATIVE)
    abstract val jniDir: DirectoryProperty

    @get:OutputDirectory abstract val libsOut: DirectoryProperty
    @get:OutputDirectory abstract val exeOut: DirectoryProperty
    @get:OutputDirectory abstract val objOut: DirectoryProperty

    @TaskAction
    fun build() {
        val isWindows = System.getProperty("os.name").startsWith("Windows")
        val ndkBuild = File(ndkDir.get(), if (isWindows) "ndk-build.cmd" else "ndk-build")
        val jni = jniDir.get().asFile
        val libs = libsOut.get().asFile
        val exe = exeOut.get().asFile

        libs.deleteRecursively(); libs.mkdirs()
        exe.deleteRecursively(); exe.mkdirs()

        execOps.exec {
            executable = ndkBuild.absolutePath
            args(
                "NDK_PROJECT_PATH=null",
                "APP_BUILD_SCRIPT=${File(jni, "Android.mk").absolutePath}",
                "NDK_APPLICATION_MK=${File(jni, "Application.mk").absolutePath}",
                "NDK_LIBS_OUT=${libs.absolutePath}",
                "NDK_OUT=${objOut.get().asFile.absolutePath}",
                "APP_ABI=${abis.get().joinToString(" ")}",
                "NDK_DEBUG=${if (debug.get()) 1 else 0}",
                "-j${Runtime.getRuntime().availableProcessors()}"
            )
        }

        // ndk-build installs executables next to the .so files. AGP only packages
        // lib*.so, so keep a copy under the real name and rename the original.
        abis.get().forEach { abi ->
            val built = File(libs, "$abi/nativeexe")
            if (built.exists()) {
                built.copyTo(File(exe, "$abi/nativeexe"), overwrite = true)
                built.renameTo(File(libs, "$abi/libnativeexe.so"))
            }
        }
    }
}

android {
    namespace = "com.example.nativeexe"
    compileSdk = 35
    ndkVersion = ndkVer

    defaultConfig {
        applicationId = "com.example.nativeexe"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += nativeAbis }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        // Extract libs to nativeLibraryDir at install time so libnativeexe.so can be exec'd.
        jniLibs { useLegacyPackaging = true }
    }

    sourceSets {
        getByName("main") {
            jniLibs.srcDir(layout.buildDirectory.dir("ndk/libs"))
        }
    }
}

val ndkBuild = tasks.register<NdkBuildTask>("ndkBuild") {
    group = "build"
    description = "Builds the JNI library and the native executable with ndk-build"
    ndkDir.set(androidComponents.sdkComponents.ndkDirectory.map { it.asFile.absolutePath })
    abis.set(nativeAbis)
    debug.set(providers.gradleProperty("ndkDebug").map { it == "1" || it == "true" }.orElse(false))
    jniDir.set(layout.projectDirectory.dir("src/main/jni"))
    libsOut.set(layout.buildDirectory.dir("ndk/libs"))
    exeOut.set(layout.buildDirectory.dir("ndk/exe"))
    objOut.set(layout.buildDirectory.dir("ndk/obj"))
}

tasks.named("preBuild") { dependsOn(ndkBuild) }
