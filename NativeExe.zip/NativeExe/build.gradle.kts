plugins {
    // AGP 8.13.x is the line that officially targets Gradle 8.13+ and runs on Gradle 9.0.x.
    // (AGP 9.x requires Gradle 9.1+.)
    id("com.android.application") version "8.13.0" apply false
}
