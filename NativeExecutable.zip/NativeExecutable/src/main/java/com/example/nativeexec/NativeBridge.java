package com.example.nativeexec;

public final class NativeBridge {
    static {
        System.loadLibrary("native_jni");
    }

    private NativeBridge() {}

    public static native String hello(String name);

    public static native int add(int a, int b);
}
