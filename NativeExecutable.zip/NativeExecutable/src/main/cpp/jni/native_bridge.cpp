#include <android/log.h>
#include <jni.h>

#include <string>

#include "core.h"

#define LOG_TAG "native_jni"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* /*reserved*/) {
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }
    LOGI("libnative_jni loaded (%s)", core::abi());
    return JNI_VERSION_1_6;
}

JNIEXPORT jstring JNICALL
Java_com_example_nativeexec_NativeBridge_hello(JNIEnv* env, jclass /*clazz*/, jstring jname) {
    std::string name = "world";
    if (jname != nullptr) {
        const char* c = env->GetStringUTFChars(jname, nullptr);
        if (c == nullptr) return nullptr;  // OutOfMemoryError ถูก throw ไว้แล้ว
        name = c;
        env->ReleaseStringUTFChars(jname, c);
    }
    return env->NewStringUTF(core::greeting(name).c_str());
}

JNIEXPORT jint JNICALL
Java_com_example_nativeexec_NativeBridge_add(JNIEnv* /*env*/, jclass /*clazz*/, jint a, jint b) {
    return core::add(a, b);
}

}  // extern "C"
