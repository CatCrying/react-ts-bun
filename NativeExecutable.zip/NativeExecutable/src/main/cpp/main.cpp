#include <sys/system_properties.h>
#include <unistd.h>

#include <cstdio>

#include "core.h"

int main(int argc, char** argv) {
    const char* name = argc > 1 ? argv[1] : "world";
    std::printf("%s\n", core::greeting(name).c_str());

    char release[PROP_VALUE_MAX] = {};
    __system_property_get("ro.build.version.release", release);

    std::printf("ABI: %s | Android: %s | target API: %d | pid: %d\n",
                core::abi(), release[0] ? release : "?", __ANDROID_API__, static_cast<int>(getpid()));
    std::printf("2 + 3 = %d\n", core::add(2, 3));
    return 0;
}
