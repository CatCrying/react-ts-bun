#include "core.h"

namespace core {

std::string greeting(std::string_view name) {
    std::string s = "Hello, ";
    s.append(name);
    s += "!";
    return s;
}

int add(int a, int b) noexcept {
    // wrap-around แบบ defined behavior แทน signed overflow (UB)
    return static_cast<int>(static_cast<unsigned>(a) + static_cast<unsigned>(b));
}

const char* abi() noexcept {
#if defined(__aarch64__)
    return "arm64-v8a";
#elif defined(__arm__)
    return "armeabi-v7a";
#elif defined(__x86_64__)
    return "x86_64";
#elif defined(__i386__)
    return "x86";
#else
    return "unknown";
#endif
}

}  // namespace core
