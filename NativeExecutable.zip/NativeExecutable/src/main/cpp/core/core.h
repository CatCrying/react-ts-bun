#pragma once
#include <string>
#include <string_view>

namespace core {

std::string greeting(std::string_view name);
int add(int a, int b) noexcept;
const char* abi() noexcept;

}  // namespace core
