rootProject.name = "NativeExecutable"
