# NativeExecutable

Android native executable + JNI library (C++20) — Gradle 9.0.0, NDK 27 LTS (r27d), ไม่ใช้ AGP

## Setup
    gradle wrapper --gradle-version 9.0.0   # สร้าง gradlew + wrapper jar (ครั้งแรก)
    export ANDROID_HOME=$HOME/Android/Sdk
    sdkmanager "ndk;27.3.13750724" "cmake;3.22.1"

## Build
    ./gradlew assembleNative                              # arm64-v8a
    ./gradlew assembleNative -Pnative.abis=arm64-v8a,armeabi-v7a,x86_64

Output: `build/outputs/native/<abi>/native_exec` และ `libnative_jni.so`

## Run บนเครื่อง (adb)
    ./gradlew runNative -Pnative.args="Iqoo"
