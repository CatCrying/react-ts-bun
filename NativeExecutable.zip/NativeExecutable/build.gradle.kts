plugins {
    java
}

group = "com.example.nativeexec"
version = "1.0.0"

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

// ───────────── Config ─────────────
fun prop(name: String, default: String): String = (findProperty(name) as String?) ?: default

val ndkVersion = prop("native.ndkVersion", "27.3.13750724")
val cmakeVersion = prop("native.cmakeVersion", "3.22.1")
val apiLevel = prop("native.api", "24")
val buildType = prop("native.buildType", "Release")
val deviceDir = prop("native.deviceDir", "/data/local/tmp")
val abis = prop("native.abis", "arm64-v8a").split(",").map { it.trim() }.filter { it.isNotEmpty() }

val sdkRoot: File? = listOf(System.getenv("ANDROID_HOME"), System.getenv("ANDROID_SDK_ROOT"))
    .firstOrNull { !it.isNullOrBlank() }
    ?.let { File(it) }

fun ndkDir(): File {
    System.getenv("ANDROID_NDK_HOME")?.takeIf { it.isNotBlank() }?.let { return File(it) }
    val root = sdkRoot ?: throw GradleException("ตั้งค่า ANDROID_HOME (หรือ ANDROID_NDK_HOME) ก่อน")
    val dir = File(root, "ndk/$ndkVersion")
    if (!dir.isDirectory) {
        throw GradleException("ไม่พบ NDK $ndkVersion ที่ $dir\nติดตั้งด้วย: sdkmanager \"ndk;$ndkVersion\"")
    }
    return dir
}

fun sdkCmakeBin(): File? =
    sdkRoot?.let { File(it, "cmake/$cmakeVersion/bin") }?.takeIf { it.isDirectory }

fun cmakeExe(): String = sdkCmakeBin()?.let { File(it, "cmake").absolutePath } ?: "cmake"

// ───────────── Native tasks (CMake + NDK) ─────────────
val cppSrc = layout.projectDirectory.dir("src/main/cpp")

val buildTasks = abis.map { abi ->
    val id = abi.replace("-", "_")
    val workDir = layout.buildDirectory.dir("native/$abi")
    val outDir = layout.buildDirectory.dir("outputs/native/$abi")

    val configure = tasks.register<Exec>("configureNative_$id") {
        group = "native"
        description = "CMake configure ($abi)"
        inputs.dir(cppSrc)
        inputs.property("cfg", "$ndkVersion|$apiLevel|$buildType")
        outputs.dir(workDir)
        doFirst {
            val args = mutableListOf(
                cmakeExe(),
                "-S", cppSrc.asFile.absolutePath,
                "-B", workDir.get().asFile.absolutePath,
                "-DCMAKE_TOOLCHAIN_FILE=${ndkDir()}/build/cmake/android.toolchain.cmake",
                "-DANDROID_ABI=$abi",
                "-DANDROID_PLATFORM=android-$apiLevel",
                "-DANDROID_STL=c++_static",
                "-DCMAKE_BUILD_TYPE=$buildType",
                "-DCMAKE_RUNTIME_OUTPUT_DIRECTORY=${outDir.get().asFile.absolutePath}",
                "-DCMAKE_LIBRARY_OUTPUT_DIRECTORY=${outDir.get().asFile.absolutePath}",
            )
            sdkCmakeBin()?.let {
                args += listOf("-G", "Ninja", "-DCMAKE_MAKE_PROGRAM=${File(it, "ninja").absolutePath}")
            }
            commandLine(args)
        }
    }

    tasks.register<Exec>("buildNative_$id") {
        group = "native"
        description = "Build native_exec + libnative_jni.so ($abi)"
        dependsOn(configure)
        inputs.dir(cppSrc)
        outputs.dir(outDir)
        doFirst {
            commandLine(cmakeExe(), "--build", workDir.get().asFile.absolutePath, "--parallel")
        }
    }
}

val assembleNative = tasks.register("assembleNative") {
    group = "native"
    description = "Build native executable + JNI library for all ABIs"
    dependsOn(buildTasks)
}
tasks.named("assemble") { dependsOn(assembleNative) }

// ───────────── Run on device (adb) ─────────────
val firstAbi = abis.first()
val firstId = firstAbi.replace("-", "_")
val exeOnHost = layout.buildDirectory.file("outputs/native/$firstAbi/native_exec")

val pushNative = tasks.register<Exec>("pushNative") {
    group = "native"
    description = "adb push native_exec ($firstAbi) -> $deviceDir"
    dependsOn("buildNative_$firstId")
    doFirst {
        commandLine(
            "sh", "-c",
            "adb push '${exeOnHost.get().asFile}' '$deviceDir/native_exec' && adb shell chmod 755 '$deviceDir/native_exec'"
        )
    }
}

tasks.register<Exec>("runNative") {
    group = "native"
    description = "Push & run on device. Args: -Pnative.args=\"foo bar\""
    dependsOn(pushNative)
    doFirst {
        val extra = prop("native.args", "").split(" ").filter { it.isNotBlank() }
        commandLine(listOf("adb", "shell", "$deviceDir/native_exec") + extra)
    }
}
